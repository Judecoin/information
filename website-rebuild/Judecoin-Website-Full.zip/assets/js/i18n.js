(function () {
  "use strict";

  var SESSION_KEY = "judecoin-session-language-stable-v1";
  var STATIC_ENGLISH_PAGES = {
    "roadmap.html": true,
    "community-news.html": true,
    "atomic-swaps.html": true,
    "service-nodes.html": true
  };

  var LANGUAGES = [
    { code: "en", name: "English", google: "en" },
    { code: "zh-TW", name: "繁體中文", google: "zh-TW" },
    { code: "de", name: "Deutsch", google: "de" },
    { code: "ja", name: "日本語", google: "ja" },
    { code: "ko", name: "한국어", google: "ko" },
    { code: "it", name: "Italiano", google: "it" },
    { code: "nl", name: "Nederlands", google: "nl" },
    { code: "ru", name: "русский язык", google: "ru" },
    { code: "es", name: "Español", google: "es" }
  ];

  var BRAND_PATTERN = /(jude\.org|\$JUDE|JUDECOIN|Judecoin|judecoin|JUDE|Jude|jude)/g;
  var googleCreated = false;
  var googleLoading = false;
  var pendingLanguage = null;
  var brandProtected = false;

  function ready(fn) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn, { once: true });
    else fn();
  }

  function pageName() {
    return (window.location.pathname || "").split("/").pop() || "index.html";
  }

  function isStaticEnglishPage() {
    var mode = document.body && document.body.getAttribute("data-i18n-mode");
    return mode === "static-en" || STATIC_ENGLISH_PAGES[pageName()] === true;
  }

  function normalize(value) {
    var raw = String(value || "").trim();
    var lower = raw.toLowerCase();
    for (var i = 0; i < LANGUAGES.length; i += 1) {
      if (LANGUAGES[i].code === raw || LANGUAGES[i].code.toLowerCase() === lower || LANGUAGES[i].name.toLowerCase() === lower) {
        return LANGUAGES[i].code;
      }
    }
    if (lower === "zh" || lower === "zh-tw" || lower === "tw" || raw === "繁體中文") return "zh-TW";
    if (lower.indexOf("de") === 0) return "de";
    if (lower.indexOf("ja") === 0 || lower.indexOf("日本") === 0) return "ja";
    if (lower.indexOf("ko") === 0 || lower.indexOf("한국") === 0) return "ko";
    if (lower.indexOf("it") === 0 || lower.indexOf("italiano") === 0) return "it";
    if (lower.indexOf("nl") === 0 || lower.indexOf("nederlands") === 0) return "nl";
    if (lower.indexOf("ru") === 0 || lower.indexOf("рус") === 0) return "ru";
    if (lower.indexOf("es") === 0 || lower.indexOf("español") === 0 || lower.indexOf("espanol") === 0) return "es";
    return "en";
  }

  function languageName(code) {
    code = normalize(code);
    for (var i = 0; i < LANGUAGES.length; i += 1) {
      if (LANGUAGES[i].code === code) return LANGUAGES[i].name;
    }
    return "English";
  }

  function googleCode(code) {
    code = normalize(code);
    for (var i = 0; i < LANGUAGES.length; i += 1) {
      if (LANGUAGES[i].code === code) return LANGUAGES[i].google;
    }
    return "en";
  }

  function readLanguage() {
    try { return normalize(sessionStorage.getItem(SESSION_KEY)); }
    catch (error) { return "en"; }
  }

  function writeLanguage(code) {
    code = normalize(code);
    try {
      if (code === "en") sessionStorage.removeItem(SESSION_KEY);
      else sessionStorage.setItem(SESSION_KEY, code);
    } catch (error) {}
    return code;
  }

  function cookieDomains() {
    var host = window.location.hostname || "";
    if (!host || host === "localhost" || host === "127.0.0.1" || /^\d+\.\d+\.\d+\.\d+$/.test(host)) return [""];
    var domains = ["", "; domain=" + host];
    var parts = host.split(".").filter(Boolean);
    if (parts.length >= 2) domains.push("; domain=." + parts.slice(-2).join("."));
    return domains;
  }

  function writeGoogTransCookie(value, maxAge) {
    var secure = window.location.protocol === "https:" ? "; Secure" : "";
    cookieDomains().forEach(function (domain) {
      document.cookie = "googtrans=" + value + "; path=/; max-age=" + maxAge + "; SameSite=Lax" + secure + domain;
    });
  }

  function clearGoogleCookie() {
    writeGoogTransCookie("/en/en", 1);
    writeGoogTransCookie("", 0);
    var secure = window.location.protocol === "https:" ? "; Secure" : "";
    cookieDomains().forEach(function (domain) {
      document.cookie = "googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax" + secure + domain;
    });
  }

  function setGoogleCookie(code) {
    code = normalize(code);
    if (code === "en") clearGoogleCookie();
    else writeGoogTransCookie("/en/" + googleCode(code), 31536000);
  }

  function updateLanguageUI(code) {
    code = normalize(code);
    document.documentElement.setAttribute("data-selected-language", code);
    document.documentElement.setAttribute("lang", isStaticEnglishPage() ? "en" : code);
    if (document.body) {
      document.body.setAttribute("data-selected-lang", code);
      document.body.setAttribute("data-static-english-page", isStaticEnglishPage() ? "true" : "false");
    }

    document.querySelectorAll(".lang-button, .language-current").forEach(function (button) {
      button.textContent = "";
      button.appendChild(document.createTextNode(languageName(code) + " "));
      var icon = document.createElement("span");
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "⌃";
      button.appendChild(icon);
      button.setAttribute("aria-label", "Language: " + languageName(code));
      button.setAttribute("aria-expanded", "false");
    });

    document.querySelectorAll(".lang-menu a, .lang-menu button, [data-lang]").forEach(function (item) {
      var itemCode = normalize(item.getAttribute("data-lang") || item.textContent);
      item.setAttribute("data-lang", itemCode);
      var active = itemCode === code;
      item.classList.toggle("active", active);
      if (active) item.setAttribute("aria-current", "true");
      else item.removeAttribute("aria-current");
    });
  }

  function closeLanguageMenus() {
    document.querySelectorAll(".lang-switch.is-open").forEach(function (switcher) {
      switcher.classList.remove("is-open");
      var button = switcher.querySelector(".lang-button, .language-current");
      if (button) {
        button.setAttribute("aria-expanded", "false");
        button.blur();
      }
    });
  }

  function openLanguageMenu(switcher) {
    document.querySelectorAll(".lang-switch.is-open").forEach(function (other) {
      if (other !== switcher) other.classList.remove("is-open");
    });
    switcher.classList.add("is-open");
    var button = switcher.querySelector(".lang-button, .language-current");
    if (button) button.setAttribute("aria-expanded", "true");
  }

  function markStaticNoTranslate() {
    if (!document.body || !isStaticEnglishPage()) return;
    document.body.classList.add("notranslate");
    document.body.setAttribute("translate", "no");
  }

  function markNoTranslateControls() {
    document.querySelectorAll([
      "script", "style", "svg", "canvas", "code", "pre", "kbd", "samp",
      ".lang-switch", ".lang-menu", ".lang-button", ".language-current",
      ".logo", ".logo-word", ".logo-mark", ".footer-social", ".asset-logo",
      "[data-live-stat]", "[data-i18n-skip]", ".notranslate"
    ].join(",")).forEach(function (node) {
      if (node.classList) node.classList.add("notranslate");
      if (node.setAttribute) node.setAttribute("translate", "no");
    });
  }

  function protectBrandTerms() {
    if (brandProtected || !document.body || !document.createTreeWalker || isStaticEnglishPage()) return;
    var skipSelector = [
      "script", "style", "svg", "canvas", "code", "pre", "kbd", "samp",
      ".lang-switch", ".lang-menu", ".logo", ".footer-social", ".asset-logo",
      "[data-live-stat]", "[data-i18n-skip]", ".notranslate"
    ].join(",");

    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
        BRAND_PATTERN.lastIndex = 0;
        if (!BRAND_PATTERN.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        if (node.parentElement && node.parentElement.closest(skipSelector)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);

    nodes.forEach(function (node) {
      var text = node.nodeValue;
      var fragment = document.createDocumentFragment();
      var lastIndex = 0;
      BRAND_PATTERN.lastIndex = 0;
      text.replace(BRAND_PATTERN, function (match, _unused, index) {
        if (index > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
        var span = document.createElement("span");
        span.className = "notranslate brand-term";
        span.setAttribute("translate", "no");
        span.textContent = match;
        fragment.appendChild(span);
        lastIndex = index + match.length;
        return match;
      });
      if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
      if (node.parentNode) node.parentNode.replaceChild(fragment, node);
    });

    brandProtected = true;
  }

  function ensureTranslateContainer() {
    var el = document.getElementById("google_translate_element");
    if (!el) {
      el = document.createElement("div");
      el.id = "google_translate_element";
      el.className = "notranslate";
      el.setAttribute("translate", "no");
      el.setAttribute("aria-hidden", "true");
      document.body.appendChild(el);
    }
    return el;
  }

  function createGoogleElement() {
    if (!window.google || !window.google.translate || !window.google.translate.TranslateElement) return false;
    ensureTranslateContainer();
    if (!googleCreated) {
      googleCreated = true;
      new window.google.translate.TranslateElement({
        pageLanguage: "en",
        includedLanguages: "zh-TW,de,ja,ko,it,nl,ru,es",
        autoDisplay: false,
        multilanguagePage: true
      }, "google_translate_element");
    }
    return true;
  }

  function triggerCombo(code) {
    code = normalize(code);
    var translated = googleCode(code);
    var combo = document.querySelector(".goog-te-combo");
    if (!combo || !translated || translated === "en") return false;
    combo.value = translated;
    combo.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function loadGoogle(callback) {
    if (isStaticEnglishPage()) return;
    ensureTranslateContainer();

    window.googleTranslateElementInit = function () {
      createGoogleElement();
      if (callback) callback();
    };

    if (window.google && window.google.translate && window.google.translate.TranslateElement) {
      createGoogleElement();
      if (callback) callback();
      return;
    }

    if (googleLoading || document.querySelector('script[data-jude-google-translate="true"]')) {
      if (callback) window.setTimeout(callback, 450);
      return;
    }

    googleLoading = true;
    var script = document.createElement("script");
    script.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    script.async = true;
    script.defer = true;
    script.setAttribute("data-jude-google-translate", "true");
    script.onerror = function () {
      googleLoading = false;
      if (document.body) document.body.setAttribute("data-translate-status", "unavailable");
    };
    document.head.appendChild(script);
  }

  function runTranslation(code) {
    code = normalize(code);
    if (code === "en" || isStaticEnglishPage()) return;
    pendingLanguage = code;
    setGoogleCookie(code);
    protectBrandTerms();
    loadGoogle(function () {
      var attempts = 0;
      var timer = window.setInterval(function () {
        attempts += 1;
        if (pendingLanguage !== code) {
          window.clearInterval(timer);
          return;
        }
        createGoogleElement();
        if (triggerCombo(code) || attempts >= 40) {
          window.clearInterval(timer);
        }
      }, 180);
    });
  }

  function applyLanguage(code, options) {
    code = normalize(code);
    options = options || {};

    document.documentElement.classList.remove("i18n-pending");
    document.documentElement.classList.add("i18n-ready");
    document.documentElement.removeAttribute("data-i18n-loading");

    markNoTranslateControls();
    updateLanguageUI(code);

    if (isStaticEnglishPage()) {
      clearGoogleCookie();
      markStaticNoTranslate();
      return;
    }

    if (code === "en") {
      pendingLanguage = "en";
      clearGoogleCookie();
      if (options.fromUser && (document.documentElement.className.indexOf("translated") !== -1 || document.querySelector(".goog-te-combo"))) {
        window.setTimeout(function () { window.location.reload(); }, 80);
      }
      return;
    }

    runTranslation(code);
  }

  function wireLanguageMenu() {
    markNoTranslateControls();

    document.querySelectorAll(".lang-switch").forEach(function (switcher) {
      switcher.classList.add("notranslate");
      switcher.setAttribute("translate", "no");
      var button = switcher.querySelector(".lang-button, .language-current");
      if (button) {
        button.setAttribute("aria-haspopup", "true");
        button.setAttribute("aria-expanded", "false");
        button.addEventListener("click", function (event) {
          event.preventDefault();
          event.stopPropagation();
          if (switcher.classList.contains("is-open")) closeLanguageMenus();
          else openLanguageMenu(switcher);
        });
      }
    });

    document.querySelectorAll(".lang-menu a, .lang-menu button").forEach(function (item) {
      var code = normalize(item.getAttribute("data-lang") || item.textContent);
      item.setAttribute("data-lang", code);
      item.setAttribute("role", "menuitem");
      item.classList.add("notranslate");
      item.setAttribute("translate", "no");
      if (item.tagName === "A") item.setAttribute("href", "#");
      item.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        closeLanguageMenus();
        writeLanguage(code);
        applyLanguage(code, { fromUser: true });
      });
    });

    document.addEventListener("click", function (event) {
      if (!event.target.closest(".lang-switch")) closeLanguageMenus();
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeLanguageMenus();
    });

    applyLanguage(readLanguage(), { fromUser: false });
  }

  window.judeSetLanguage = function (code) {
    closeLanguageMenus();
    writeLanguage(code);
    applyLanguage(code, { fromUser: true });
  };

  ready(wireLanguageMenu);
})();
