(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn, { once: true });
    else fn();
  }

  function enforceHttps() {
    var host = window.location.hostname;
    var isLocal = !host || host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0";
    if (window.location.protocol === "http:" && !isLocal) {
      window.location.replace("https://" + window.location.host + window.location.pathname + window.location.search + window.location.hash);
    }
  }

  function initMobileNavigation() {
    var header = document.querySelector(".site-header, .header");
    if (!header) return;

    var desktopNav = header.querySelector(".nav");
    var actions = header.querySelector(".header-actions, .actions") || header;

    var download = header.querySelector('.header-actions a.btn-primary, .actions a.btn-primary, a[href="downloads.html"]');
    if (download) {
      download.classList.add("header-download-link");
      download.setAttribute("aria-label", "Download Wallet");
      download.setAttribute("title", "Download Wallet");
    }

    var toggle = header.querySelector("[data-mobile-menu-toggle]");
    if (!toggle) {
      toggle = document.createElement("button");
      toggle.className = "mobile-menu-toggle";
      toggle.type = "button";
      toggle.setAttribute("data-mobile-menu-toggle", "");
      toggle.setAttribute("aria-label", "Open navigation");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-controls", "mobileNav");
      toggle.innerHTML = "<span></span><span></span><span></span>";
      actions.appendChild(toggle);
    }

    var panel = document.getElementById("mobileNav");
    if (!panel) {
      panel = document.createElement("aside");
      panel.id = "mobileNav";
      panel.className = "mobile-nav-panel";
      panel.setAttribute("aria-hidden", "true");
      panel.setAttribute("aria-label", "Mobile navigation");

      var inner = document.createElement("div");
      inner.className = "mobile-nav-inner";

      if (desktopNav) {
        Array.prototype.forEach.call(desktopNav.querySelectorAll(".nav-item"), function (item) {
          var group = document.createElement("section");
          group.className = "mobile-nav-group";
          var title = document.createElement("strong");
          var titleButton = item.querySelector(".nav-button");
          title.textContent = titleButton ? titleButton.textContent.trim().replace(/[⌄⌃]/g, "") : "Navigation";
          group.appendChild(title);

          Array.prototype.forEach.call(item.querySelectorAll(".dropdown a"), function (link) {
            var clone = link.cloneNode(true);
            clone.removeAttribute("style");
            group.appendChild(clone);
          });
          inner.appendChild(group);
        });
      }

      panel.appendChild(inner);
      header.insertAdjacentElement("afterend", panel);
    }

    function setOpen(open) {
      document.body.classList.toggle("mobile-nav-open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
      panel.setAttribute("aria-hidden", String(!open));
    }

    toggle.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      setOpen(!document.body.classList.contains("mobile-nav-open"));
    });

    panel.addEventListener("click", function (event) {
      if (event.target.closest("a")) setOpen(false);
    });

    document.addEventListener("click", function (event) {
      if (!document.body.classList.contains("mobile-nav-open")) return;
      if (panel.contains(event.target) || toggle.contains(event.target)) return;
      setOpen(false);
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") setOpen(false);
    });

    window.addEventListener("resize", function () {
      if (window.innerWidth > 1040) setOpen(false);
    }, { passive: true });
  }

  enforceHttps();
  ready(initMobileNavigation);
})();
