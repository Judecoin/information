(() => {
  const root = document.documentElement;
  const toggle = document.querySelector("[data-theme-toggle], .theme-toggle");
  const key = "judecoin-homepage-theme";
  const legacy = localStorage.getItem("jude-theme");
  const stored = localStorage.getItem(key) || legacy || root.getAttribute("data-theme") || "light";
  const apply = theme => {
    root.setAttribute("data-theme", theme);
    if (toggle) toggle.textContent = theme === "dark" ? "☾" : "☀";
  };
  apply(stored);
  if (toggle) {
    toggle.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      localStorage.setItem(key, next);
      localStorage.setItem("jude-theme", next);
      apply(next);
    });
  }
  if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    document.body.classList.add("motion-ready");
    const items = document.querySelectorAll(".reveal");
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach((item, index) => {
      item.style.transitionDelay = `${Math.min(index * 45, 260)}ms`;
      observer.observe(item);
    });
  }
})();
