(() => {
  const root = document.documentElement;
  const key = "judecoin-homepage-theme";
  const saved = localStorage.getItem(key) || "light";
  const toggle = document.querySelector("[data-theme-toggle]");
  const apply = theme => {
    root.setAttribute("data-theme", theme);
    if (toggle) toggle.textContent = theme === "dark" ? "☾" : "☀";
  };
  apply(saved);
  if (toggle) {
    toggle.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      localStorage.setItem(key, next);
      apply(next);
    });
  }
})();
