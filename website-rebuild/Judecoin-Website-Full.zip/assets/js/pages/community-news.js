(() => {
  const root = document.documentElement;
  const themeKey = "judecoin-theme";
  const toggle = document.querySelector("[data-theme-toggle]");
  const saved = localStorage.getItem("judecoin-homepage-theme") || localStorage.getItem(themeKey) || localStorage.getItem("jude-theme") || "light";
  const applyTheme = theme => {
    root.setAttribute("data-theme", theme);
    if (toggle) toggle.textContent = theme === "dark" ? "☾" : "☀";
  };
  applyTheme(saved);
  if (toggle) {
    toggle.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      localStorage.setItem(themeKey, next);
      localStorage.setItem("judecoin-homepage-theme", next);
      applyTheme(next);
    });
  }

  const tabs = Array.from(document.querySelectorAll("[data-year-tab]"));
  const panels = Array.from(document.querySelectorAll("[data-year-panel]"));
  function activateYear(year, scrollToTop = false) {
    tabs.forEach(tab => tab.setAttribute("aria-selected", String(tab.dataset.yearTab === year)));
    panels.forEach(panel => {
      const active = panel.dataset.yearPanel === year;
      panel.hidden = !active;
    });
    if (scrollToTop) {
      const target = document.querySelector(".archive-area");
      if (target) target.scrollIntoView({behavior:"smooth", block:"start"});
    }
  }
  tabs.forEach(tab => tab.addEventListener("click", () => activateYear(tab.dataset.yearTab, true)));
})();
