(function(){
  var root = document.documentElement;
  var btn = document.querySelector('[data-theme-toggle]');
  var saved = localStorage.getItem('judecoin-homepage-theme') || localStorage.getItem('jude-theme');
  if (saved === 'light' || saved === 'dark') root.setAttribute('data-theme', saved);
  function sync(){ if (btn) btn.textContent = root.getAttribute('data-theme') === 'dark' ? '☾' : '☀'; }
  sync();
  if (btn) btn.addEventListener('click', function(){
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    localStorage.setItem('judecoin-homepage-theme', next);
    localStorage.setItem('jude-theme', next);
    sync();
  });
})();
