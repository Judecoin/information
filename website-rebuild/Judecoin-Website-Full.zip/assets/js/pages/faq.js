(() => {
  const root = document.documentElement;
  const key = "judecoin-homepage-theme";
  const toggle = document.querySelector("[data-theme-toggle]");
  const saved = localStorage.getItem(key) || localStorage.getItem("jude-theme") || root.getAttribute("data-theme") || "light";
  const apply = theme => {
    root.setAttribute("data-theme", theme);
    if (toggle) toggle.textContent = theme === "dark" ? "☾" : "☀";
  };
  apply(saved);
  if (toggle) {
    toggle.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      localStorage.setItem(key, next);
      localStorage.setItem("jude-theme", next);
      apply(next);
    });
  }
  const links = Array.from(document.querySelectorAll(".category-link"));
  const sections = links.map(link => document.querySelector(link.getAttribute("href"))).filter(Boolean);
  const setActive = id => {
    links.forEach(link => link.classList.toggle("is-active", link.getAttribute("href") === `#${id}`));
  };
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActive(visible.target.id);
    }, { rootMargin: "-18% 0px -68% 0px", threshold: [0.08, 0.18, 0.28] });
    sections.forEach(section => observer.observe(section));
  }
})();
