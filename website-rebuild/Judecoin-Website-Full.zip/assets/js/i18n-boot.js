(function () {
  "use strict";

  var SESSION_KEY = "judecoin-session-language-stable-v1";
  var LEGACY_KEYS = [
    "judecoin_language",
    "judecoin-language",
    "jude-language",
    "judecoin_selected_language",
    "judecoin_active_language",
    "judecoin-session-language-v3",
    "judecoin-session-language-v4",
    "judecoin_language_session_v1"
  ];

  var SUPPORTED = {
    "en": true,
    "zh-TW": true,
    "de": true,
    "ja": true,
    "ko": true,
    "it": true,
    "nl": true,
    "ru": true,
    "es": true
  };

  var STATIC_ENGLISH_PAGES = {
    "roadmap.html": true,
    "community-news.html": true,
    "atomic-swaps.html": true,
    "service-nodes.html": true
  };

  function pageName() {
    return (window.location.pathname || "").split("/").pop() || "index.html";
  }

  function normalize(value) {
    var raw = String(value || "").trim();
    var lower = raw.toLowerCase();
    if (SUPPORTED[raw]) return raw;
    if (lower === "zh" || lower === "zh-tw" || lower === "tw" || raw === "繁體中文") return "zh-TW";
    if (lower === "de" || lower.indexOf("deutsch") === 0) return "de";
    if (lower === "ja" || lower.indexOf("日本") === 0) return "ja";
    if (lower === "ko" || lower.indexOf("한국") === 0) return "ko";
    if (lower === "it" || lower.indexOf("italiano") === 0) return "it";
    if (lower === "nl" || lower.indexOf("nederlands") === 0) return "nl";
    if (lower === "ru" || lower.indexOf("рус") === 0) return "ru";
    if (lower === "es" || lower.indexOf("español") === 0 || lower.indexOf("espanol") === 0) return "es";
    return "en";
  }

  function cookieDomains() {
    var host = window.location.hostname || "";
    if (!host || host === "localhost" || host === "127.0.0.1" || /^\d+\.\d+\.\d+\.\d+$/.test(host)) return [""];
    var domains = ["", "; domain=" + host];
    var parts = host.split(".").filter(Boolean);
    if (parts.length >= 2) domains.push("; domain=." + parts.slice(-2).join("."));
    return domains;
  }

  function writeGoogTransCookie(value, maxAge) {
    var secure = window.location.protocol === "https:" ? "; Secure" : "";
    cookieDomains().forEach(function (domain) {
      document.cookie = "googtrans=" + value + "; path=/; max-age=" + maxAge + "; SameSite=Lax" + secure + domain;
    });
  }

  function clearGoogleCookie() {
    writeGoogTransCookie("/en/en", 1);
    writeGoogTransCookie("", 0);
    var secure = window.location.protocol === "https:" ? "; Secure" : "";
    cookieDomains().forEach(function (domain) {
      document.cookie = "googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax" + secure + domain;
    });
  }

  function setGoogleCookie(code) {
    code = normalize(code);
    if (code === "en") clearGoogleCookie();
    else writeGoogTransCookie("/en/" + code, 31536000);
  }

  function clearOldLanguageState() {
    try {
      LEGACY_KEYS.forEach(function (key) {
        localStorage.removeItem(key);
        if (key !== SESSION_KEY) sessionStorage.removeItem(key);
      });
      Object.keys(localStorage).forEach(function (key) {
        if (key.indexOf("judecoin-i18n-cache") === 0) localStorage.removeItem(key);
      });
      Object.keys(sessionStorage).forEach(function (key) {
        if (key.indexOf("judecoin-i18n-cache") === 0) sessionStorage.removeItem(key);
      });
    } catch (error) {}
  }

  clearOldLanguageState();

  var selected = "en";
  try { selected = normalize(sessionStorage.getItem(SESSION_KEY)); }
  catch (error) { selected = "en"; }

  var staticEnglishPage = STATIC_ENGLISH_PAGES[pageName()] === true;

  document.documentElement.setAttribute("data-selected-language", selected);
  document.documentElement.setAttribute("lang", staticEnglishPage ? "en" : selected);
  document.documentElement.classList.add("i18n-ready");
  document.documentElement.classList.remove("i18n-pending");
  document.documentElement.removeAttribute("data-i18n-loading");

  if (staticEnglishPage || selected === "en") clearGoogleCookie();
  else setGoogleCookie(selected);
})();
